"""
OSC Chatbox Installer Wizard
Made By Boots
"""

import subprocess
import sys
import os
import json
import threading
import zipfile
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────

INSTALL_DIR = Path(os.getenv("LOCALAPPDATA")) / "OSC-Chatbox"
LHM_VERSION = "0.9.4"
LHM_ZIP_URL = f"https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/download/v{LHM_VERSION}/LibreHardwareMonitor-net472.zip"
LHM_DIR = INSTALL_DIR / "LibreHardwareMonitor"
LHM_EXE = LHM_DIR / "LibreHardwareMonitor.exe"
OSC_SCRIPT = INSTALL_DIR / "OSC-Windows-Stable.py"

REQUIRED_PACKAGES = [
    ("python-osc==1.9.3", "pythonosc"),
    ("psutil==7.2.2", "psutil"),
    ("winrt-Windows.Media.Control==3.2.1", "winrt"),
    ("winrt-windows.foundation==3.2.1", "winrt.windows.foundation"),
    ("requests==2.32.5", "requests"),
]

BG = "#121212"
FG = "#E0E0E0"
ACCENT = "#4CFF4C"
BTN_BG = "#2A2A2A"
BTN_FG = "#FFFFFF"
ENTRY_BG = "#1E1E1E"
ERROR = "#FF4C4C"


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def pip_install(package: str) -> tuple[bool, str]:
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", package, "--quiet"],
        capture_output=True, text=True
    )
    return result.returncode == 0, result.stderr


def is_lhm_running() -> bool:
    try:
        import urllib.request
        urllib.request.urlopen("http://localhost:8085/data.json", timeout=3)
        return True
    except Exception:
        return False


def download_file(url: str, dest: Path, progress_cb=None):
    """Download with optional progress callback(percent: int)"""
    def reporthook(block, block_size, total):
        if total > 0 and progress_cb:
            pct = min(int(block * block_size * 100 / total), 100)
            progress_cb(pct)

    urllib.request.urlretrieve(url, dest, reporthook=reporthook)


# ─────────────────────────────────────────────────────────────────────────────
# WIZARD
# ─────────────────────────────────────────────────────────────────────────────

class InstallerWizard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OSC Chatbox Installer")
        self.geometry("560x440")
        self.resizable(False, False)
        self.configure(bg=BG)

        # Center window
        self.eval('tk::PlaceWindow . center')

        self.current_page = 0
        self.pages = []

        self._build_header()
        self._build_content_area()
        self._build_nav()

        self._build_page_welcome()
        self._build_page_packages()
        self._build_page_lhm()
        self._build_page_copy_script()
        self._build_page_done()

        self._show_page(0)

    # ── Layout ────────────────────────────────────────────────────────────────

    def _build_header(self):
        hdr = tk.Frame(self, bg="#1A1A2E", height=60)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="OSC Chatbox Installer", font=("Segoe UI", 16, "bold"),
                 bg="#1A1A2E", fg=ACCENT).pack(side="left", padx=20, pady=10)
        tk.Label(hdr, text="Made By Boots", font=("Segoe UI", 9),
                 bg="#1A1A2E", fg="#888888").pack(side="right", padx=20)

    def _build_content_area(self):
        self.content = tk.Frame(self, bg=BG)
        self.content.pack(fill="both", expand=True, padx=20, pady=10)

    def _build_nav(self):
        nav = tk.Frame(self, bg="#1A1A1A", height=50)
        nav.pack(fill="x", side="bottom")
        nav.pack_propagate(False)

        self.back_btn = tk.Button(nav, text="← Back", command=self._go_back,
                                  bg=BTN_BG, fg=BTN_FG, relief="flat",
                                  padx=16, font=("Segoe UI", 10))
        self.back_btn.pack(side="left", padx=15, pady=10)

        self.next_btn = tk.Button(nav, text="Next →", command=self._go_next,
                                  bg="#2A5A2A", fg=BTN_FG, relief="flat",
                                  padx=16, font=("Segoe UI", 10, "bold"))
        self.next_btn.pack(side="right", padx=15, pady=10)

        self.step_label = tk.Label(nav, text="Step 1 of 5", bg="#1A1A1A", fg="#888888",
                                   font=("Segoe UI", 9))
        self.step_label.pack(side="right", padx=5)

    # ── Page management ───────────────────────────────────────────────────────

    def _show_page(self, index: int):
        for widget in self.content.winfo_children():
            widget.pack_forget()
        self.current_page = index
        self.pages[index]()
        self.step_label.config(text=f"Step {index + 1} of {len(self.pages)}")
        self.back_btn.config(state="normal" if index > 0 else "disabled")
        last = index == len(self.pages) - 1
        self.next_btn.config(text="Finish" if last else "Next →",
                             command=self.destroy if last else self._go_next)

    def _go_next(self):
        if self.current_page < len(self.pages) - 1:
            self._show_page(self.current_page + 1)

    def _go_back(self):
        if self.current_page > 0:
            self._show_page(self.current_page - 1)

    def _register(self, fn):
        self.pages.append(fn)

    # ── Shared widgets ────────────────────────────────────────────────────────

    def _page_title(self, title: str, subtitle: str = ""):
        tk.Label(self.content, text=title, font=("Segoe UI", 13, "bold"),
                 bg=BG, fg=FG).pack(anchor="w", pady=(4, 0))
        if subtitle:
            tk.Label(self.content, text=subtitle, font=("Segoe UI", 9),
                     bg=BG, fg="#888888", wraplength=500, justify="left").pack(anchor="w")
        ttk.Separator(self.content).pack(fill="x", pady=8)

    def _log_box(self) -> tk.Text:
        box = tk.Text(self.content, bg=ENTRY_BG, fg="#AAFFAA", font=("Consolas", 9),
                      relief="flat", height=12, state="disabled", wrap="word")
        box.pack(fill="both", expand=True)
        return box

    def _log(self, box: tk.Text, text: str, color: str = "#AAFFAA"):
        box.config(state="normal")
        box.tag_config(color, foreground=color)
        box.insert("end", text + "\n", color)
        box.see("end")
        box.config(state="disabled")
        self.update_idletasks()

    # ── PAGE 1: Welcome ───────────────────────────────────────────────────────

    def _build_page_welcome(self):
        def show():
            self._page_title("Welcome!", "This wizard will set up everything you need to run OSC Chatbox.")

            info = [
                ("📦", "Install Python pip packages"),
                ("🖥️",  "Download & set up LibreHardwareMonitor"),
                ("📋",  "Copy OSC Chatbox script to your AppData"),
                ("🚀",  "Launch the app"),
            ]
            for icon, text in info:
                row = tk.Frame(self.content, bg=BG)
                row.pack(anchor="w", pady=4, padx=10)
                tk.Label(row, text=icon, font=("Segoe UI", 14), bg=BG).pack(side="left", padx=(0, 10))
                tk.Label(row, text=text, font=("Segoe UI", 10), bg=BG, fg=FG).pack(side="left")

            tk.Label(self.content, bg=BG, fg="#888888",
                     text="\n⚠  Administrator rights are required for hardware monitoring.\n"
                          "   Run install.bat as Admin if you haven't already.",
                     font=("Segoe UI", 9), wraplength=500, justify="left").pack(anchor="w", padx=10)

        self._register(show)

    # ── PAGE 2: Install pip packages ─────────────────────────────────────────

    def _build_page_packages(self):
        def show():
            self._page_title("Installing Python Packages",
                              "Click 'Install Packages' to download all required dependencies.")

            self.pkg_log = self._log_box()
            self.next_btn.config(state="disabled")

            btn = tk.Button(self.content, text="▶ Install Packages", command=_run,
                            bg="#2A5A2A", fg=BTN_FG, relief="flat",
                            padx=12, font=("Segoe UI", 10, "bold"))
            btn.pack(pady=8)
            self._pkg_install_btn = btn

        def _run():
            self._pkg_install_btn.config(state="disabled")
            threading.Thread(target=_worker, daemon=True).start()

        def _worker():
            all_ok = True
            for package, _ in REQUIRED_PACKAGES:
                self._log(self.pkg_log, f"Installing {package}...", "#AAAAFF")
                ok, err = pip_install(package)
                if ok:
                    self._log(self.pkg_log, f"  ✓ {package}", ACCENT)
                else:
                    self._log(self.pkg_log, f"  ✗ {package}: {err.strip()}", ERROR)
                    all_ok = False

            if all_ok:
                self._log(self.pkg_log, "\n✅ All packages installed!", ACCENT)
                self.next_btn.config(state="normal")
            else:
                self._log(self.pkg_log, "\n⚠  Some packages failed. Check your internet connection.", ERROR)
                self._pkg_install_btn.config(state="normal")

        self._register(show)

    # ── PAGE 3: LibreHardwareMonitor ──────────────────────────────────────────

    def _build_page_lhm(self):
        def show():
            self._page_title("LibreHardwareMonitor Setup",
                              "LHM is required for CPU/GPU temperature and wattage readings.")

            self.lhm_log = self._log_box()
            self.next_btn.config(state="disabled")

            btn_frame = tk.Frame(self.content, bg=BG)
            btn_frame.pack(pady=6)

            self._lhm_dl_btn = tk.Button(btn_frame, text="⬇ Download LHM", command=_download,
                                          bg="#2A2A5A", fg=BTN_FG, relief="flat",
                                          padx=10, font=("Segoe UI", 10))
            self._lhm_dl_btn.grid(row=0, column=0, padx=4)

            tk.Button(btn_frame, text="▶ Launch LHM", command=_launch,
                      bg=BTN_BG, fg=BTN_FG, relief="flat",
                      padx=10, font=("Segoe UI", 10)).grid(row=0, column=1, padx=4)

            tk.Button(btn_frame, text="🔍 Test Connection", command=_test,
                      bg=BTN_BG, fg=BTN_FG, relief="flat",
                      padx=10, font=("Segoe UI", 10)).grid(row=0, column=2, padx=4)

            tk.Label(self.content, bg=BG, fg="#888888",
                     text="After launching LHM: go to Options → Web Server → check 'Run' → set port 8085",
                     font=("Segoe UI", 8), wraplength=500).pack()

            # Check if already installed
            if LHM_EXE.exists():
                self._log(self.lhm_log, f"✓ LHM already found at: {LHM_EXE}", ACCENT)
                self._lhm_dl_btn.config(text="Re-download LHM")

            if is_lhm_running():
                self._log(self.lhm_log, "✓ LHM REST API is already running on port 8085!", ACCENT)
                self.next_btn.config(state="normal")

        def _download():
            self._lhm_dl_btn.config(state="disabled")
            threading.Thread(target=_dl_worker, daemon=True).start()

        def _dl_worker():
            try:
                LHM_DIR.mkdir(parents=True, exist_ok=True)
                zip_path = LHM_DIR / "lhm.zip"
                self._log(self.lhm_log, f"Downloading LibreHardwareMonitor v{LHM_VERSION}...", "#AAAAFF")

                def progress(pct):
                    self._log(self.lhm_log, f"  {pct}%", "#888888") if pct % 20 == 0 else None

                download_file(LHM_ZIP_URL, zip_path, progress)
                self._log(self.lhm_log, "Extracting...", "#AAAAFF")

                with zipfile.ZipFile(zip_path, 'r') as z:
                    z.extractall(LHM_DIR)
                zip_path.unlink()

                self._log(self.lhm_log, f"✓ Extracted to: {LHM_DIR}", ACCENT)

                # Find .exe in case it's in a subfolder
                exes = list(LHM_DIR.rglob("LibreHardwareMonitor.exe"))
                if exes and exes[0] != LHM_EXE:
                    import shutil
                    shutil.move(str(exes[0]), str(LHM_EXE))

                self._log(self.lhm_log, "✓ Download complete! Click 'Launch LHM' next.", ACCENT)
            except Exception as e:
                self._log(self.lhm_log, f"✗ Download failed: {e}", ERROR)
            finally:
                self._lhm_dl_btn.config(state="normal")

        def _launch():
            if not LHM_EXE.exists():
                self._log(self.lhm_log, "✗ LHM not found. Download it first.", ERROR)
                return
            try:
                subprocess.Popen([str(LHM_EXE)], shell=True)
                self._log(self.lhm_log, "✓ LHM launched! Now enable the web server in Options → Web Server.", ACCENT)
            except Exception as e:
                self._log(self.lhm_log, f"✗ Failed to launch: {e}", ERROR)

        def _test():
            if is_lhm_running():
                self._log(self.lhm_log, "✅ Connection SUCCESS — LHM REST API is live on port 8085!", ACCENT)
                self.next_btn.config(state="normal")
            else:
                self._log(self.lhm_log, "✗ Cannot reach LHM on port 8085. Make sure it's running and web server is enabled.", ERROR)

        self._register(show)

    # ── PAGE 4: Copy script ───────────────────────────────────────────────────

    def _build_page_copy_script(self):
        def show():
            self._page_title("Install OSC Chatbox Script",
                              f"The script will be copied to:\n{INSTALL_DIR}")

            self.copy_log = self._log_box()
            self.next_btn.config(state="disabled")

            btn_frame = tk.Frame(self.content, bg=BG)
            btn_frame.pack(pady=6)

            tk.Button(btn_frame, text="📋 Install Script", command=_install,
                      bg="#2A5A2A", fg=BTN_FG, relief="flat",
                      padx=12, font=("Segoe UI", 10, "bold")).grid(row=0, column=0, padx=4)

            tk.Button(btn_frame, text="🖥 Create Desktop Shortcut", command=_shortcut,
                      bg=BTN_BG, fg=BTN_FG, relief="flat",
                      padx=10, font=("Segoe UI", 10)).grid(row=0, column=1, padx=4)

        def _install():
            import shutil
            try:
                INSTALL_DIR.mkdir(parents=True, exist_ok=True)

                # Copy the main script (look next to installer.py first)
                src_candidates = [
                    Path(__file__).parent / "OSC-Windows-Stable.py",
                    Path(__file__).parent / "osc_chatbox.py",
                ]
                src = next((p for p in src_candidates if p.exists()), None)

                if src:
                    shutil.copy2(src, OSC_SCRIPT)
                    self._log(self.copy_log, f"✓ Copied {src.name} → {OSC_SCRIPT}", ACCENT)
                else:
                    self._log(self.copy_log, "⚠  Main script not found next to installer.", "#FFFF44")
                    self._log(self.copy_log, f"   Manually copy your .py file to:\n   {INSTALL_DIR}", "#FFFF44")

                # Write a launcher batch file
                launcher = INSTALL_DIR / "Launch OSC Chatbox.bat"
                launcher.write_text(
                    f'@echo off\ncd /d "{INSTALL_DIR}"\npython "{OSC_SCRIPT}"\npause\n'
                )
                self._log(self.copy_log, f"✓ Created launcher: {launcher}", ACCENT)
                self._log(self.copy_log, "\n✅ Installation complete!", ACCENT)
                self.next_btn.config(state="normal")

            except Exception as e:
                self._log(self.copy_log, f"✗ Error: {e}", ERROR)

        def _shortcut():
            try:
                desktop = Path.home() / "Desktop"
                launcher = INSTALL_DIR / "Launch OSC Chatbox.bat"

                ps = f"""
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut('{desktop / "OSC Chatbox.lnk"}')
$sc.TargetPath = '{launcher}'
$sc.WorkingDirectory = '{INSTALL_DIR}'
$sc.Description = 'OSC Chatbox by Boots'
$sc.Save()
"""
                subprocess.run(["powershell", "-Command", ps], capture_output=True)
                self._log(self.copy_log, f"✓ Desktop shortcut created!", ACCENT)
            except Exception as e:
                self._log(self.copy_log, f"✗ Shortcut failed: {e}", ERROR)

        self._register(show)

    # ── PAGE 5: Done ──────────────────────────────────────────────────────────

    def _build_page_done(self):
        def show():
            self._page_title("🎉 All Done!", "OSC Chatbox is ready to run.")

            steps = [
                "1️⃣  Make sure LibreHardwareMonitor is running",
                "2️⃣  In LHM: Options → Web Server → Enable on port 8085",
                "3️⃣  In VRChat: make sure OSC is enabled (Settings → OSC)",
                "4️⃣  Launch 'OSC Chatbox' from your desktop or AppData folder",
            ]
            for s in steps:
                tk.Label(self.content, text=s, font=("Segoe UI", 10),
                         bg=BG, fg=FG, anchor="w", wraplength=500).pack(anchor="w", pady=3, padx=10)

            tk.Label(self.content, text="\n💜 Thanks for using OSC Chatbox by Boots!",
                     font=("Segoe UI", 11, "italic"), bg=BG, fg=ACCENT).pack(pady=15)

            btn_frame = tk.Frame(self.content, bg=BG)
            btn_frame.pack()

            tk.Button(btn_frame, text="▶ Launch Now",
                      command=lambda: subprocess.Popen([sys.executable, str(OSC_SCRIPT)]),
                      bg="#2A5A2A", fg=BTN_FG, relief="flat",
                      padx=14, font=("Segoe UI", 10, "bold")).grid(row=0, column=0, padx=6)

            tk.Button(btn_frame, text="📁 Open Install Folder",
                      command=lambda: subprocess.Popen(["explorer", str(INSTALL_DIR)]),
                      bg=BTN_BG, fg=BTN_FG, relief="flat",
                      padx=10, font=("Segoe UI", 10)).grid(row=0, column=1, padx=6)

        self._register(show)


# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = InstallerWizard()
    app.mainloop()
