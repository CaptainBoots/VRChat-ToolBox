@echo off
title OSC Chatbox Installer
color 0A

echo ============================================
echo     OSC Chatbox Installer - By Boots
echo ============================================
echo.

:: Check for admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Check if Python is installed
echo [*] Checking for Python...
python --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Python not found. Downloading Python 3.11...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\python_installer.exe'"
    echo [*] Installing Python (this may take a minute)...
    "%TEMP%\python_installer.exe" /quiet InstallAllUsers=1 PrependPath=1 Include_pip=1
    del "%TEMP%\python_installer.exe"
    :: Refresh PATH
    call refreshenv >nul 2>&1
    :: Re-check
    python --version >nul 2>&1
    if %errorLevel% neq 0 (
        echo [X] Python install failed. Please install Python 3.11+ manually from python.org
        pause
        exit /b 1
    )
    echo [OK] Python installed successfully!
) else (
    for /f "tokens=*" %%i in ('python --version') do echo [OK] Found %%i
)

echo.
echo [*] Launching installer wizard...
python "%~dp0installer.py"

if %errorLevel% neq 0 (
    echo.
    echo [X] Installer encountered an error.
    pause
)
